﻿namespace Quiz9._10._15
{
    partial class Quiz2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClickMe = new System.Windows.Forms.Button();
            this.pctBoxDisplay = new System.Windows.Forms.PictureBox();
            this.lblCountDownTimer = new System.Windows.Forms.Label();
            this.lblThanks = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctBoxDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClickMe
            // 
            this.btnClickMe.Location = new System.Drawing.Point(115, 240);
            this.btnClickMe.Name = "btnClickMe";
            this.btnClickMe.Size = new System.Drawing.Size(75, 23);
            this.btnClickMe.TabIndex = 0;
            this.btnClickMe.Text = "Click Me!";
            this.btnClickMe.UseVisualStyleBackColor = true;
            this.btnClickMe.Click += new System.EventHandler(this.btnClickMe_Click);
            // 
            // pctBoxDisplay
            // 
            this.pctBoxDisplay.Location = new System.Drawing.Point(60, 60);
            this.pctBoxDisplay.Name = "pctBoxDisplay";
            this.pctBoxDisplay.Size = new System.Drawing.Size(191, 131);
            this.pctBoxDisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctBoxDisplay.TabIndex = 1;
            this.pctBoxDisplay.TabStop = false;
            this.pctBoxDisplay.Click += new System.EventHandler(this.pctBoxDisplay_Click);
            // 
            // lblCountDownTimer
            // 
            this.lblCountDownTimer.AutoSize = true;
            this.lblCountDownTimer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCountDownTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F);
            this.lblCountDownTimer.Location = new System.Drawing.Point(12, 9);
            this.lblCountDownTimer.Name = "lblCountDownTimer";
            this.lblCountDownTimer.Size = new System.Drawing.Size(2, 15);
            this.lblCountDownTimer.TabIndex = 2;
            // 
            // lblThanks
            // 
            this.lblThanks.AutoSize = true;
            this.lblThanks.Location = new System.Drawing.Point(103, 210);
            this.lblThanks.Name = "lblThanks";
            this.lblThanks.Size = new System.Drawing.Size(98, 13);
            this.lblThanks.TabIndex = 3;
            this.lblThanks.Text = "Thanks for Playing!";
            // 
            // Quiz2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 289);
            this.Controls.Add(this.lblThanks);
            this.Controls.Add(this.lblCountDownTimer);
            this.Controls.Add(this.pctBoxDisplay);
            this.Controls.Add(this.btnClickMe);
            this.Name = "Quiz2";
            this.Text = "Quiz";
            ((System.ComponentModel.ISupportInitialize)(this.pctBoxDisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClickMe;
        private System.Windows.Forms.PictureBox pctBoxDisplay;
        private System.Windows.Forms.Label lblCountDownTimer;
        private System.Windows.Forms.Label lblThanks;
    }
}

