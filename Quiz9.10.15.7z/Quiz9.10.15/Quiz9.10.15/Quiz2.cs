﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Quiz9._10._15
{
    /// <summary>
    /// Program:     Quiz
    /// Programmer:  Ryan Heath
    /// Date:        9/10/2015
    /// Description: Using a click event to generate different images in a picture box and create a sound.
    /// </summary>
    public partial class Quiz2 : Form
    {
        //Counter used to track dialog responses from Click Me event and then used to determine next image to be displayed/event to happen.
        int currentPositionCounter = 0;
        //Determines when Halloween is.
        DateTime halloween = new DateTime(2015, 10, 31, 12, 0, 01);
        public Quiz2()
        {
            InitializeComponent();
            //Hide thanks label intially.
            lblThanks.Hide();
            //Setting up a timer to constantly update the label with the up to date count down time.
            Timer ticker = new Timer();
            ticker.Interval = 500;
            ticker.Tick += new EventHandler(countDownTicker);
            //Initial setting of the countdown time.
            TimeSpan ts = halloween.Subtract(DateTime.Now);
            lblCountDownTimer.Text = ts.ToString("d' Days 'h' Hours 'm' Minutes 's' Seconds'");
            ticker.Start();
        }

        void countDownTicker(object sender, EventArgs e)
        {
            //Method called by the ticker to update the count down timer.
            TimeSpan timeRemaining = halloween.Subtract(DateTime.Now);
            lblCountDownTimer.Text = timeRemaining.ToString("d' Days 'h' Hours 'm' Minutes 's' Seconds till Halloween'");
        }

        private void pictureChange()
        {
            //Switch statement that uses the global counter, currentPositionCounter, to determine next image to be displayed and next event to happen.
            switch (currentPositionCounter)
            {
                //Case 1-5 will change the image in pctBoxDisplay to the image set below from the resoureces folder.
                case 1:
                    pctBoxDisplay.Image = Properties.Resources.fullMoon;
                    break;
                case 2:
                    pctBoxDisplay.Image = Properties.Resources.werewolf;
                    break;
                case 3:
                    pctBoxDisplay.Image = Properties.Resources.graveyard;
                    break;
                case 4:
                    pctBoxDisplay.Image = Properties.Resources.vampire;
                    break;
                case 5:
                    pctBoxDisplay.Image = Properties.Resources.screamingPerson;
                    //Plays the scream sound.
                    SoundPlayer player = new SoundPlayer(Properties.Resources.scream);
                    player.Play();
                    //Displays the "Thanks For Playing!" label.
                    lblThanks.Show();
                    //Informs the user that they have finished the game and that it is now closing.
                    MessageBox.Show("Ending Application", "Congratulations", MessageBoxButtons.OK);
                    Application.Exit();
                    break;
                default:
                    break;
            }
            return;
        }

        private void continueCheck()
        {
            //Loop that checks the dialog response and determines what the next step the program is going to take.
            DialogResult userResponse;
            do
            {
                userResponse = MessageBox.Show("Do you want to continue?", "Continue?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (userResponse == DialogResult.No)
                    Application.Exit();
                else
                {
                    currentPositionCounter++;
                    return;
                }
            } while (userResponse == DialogResult.Yes);
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            //Calls the continueCheck method to confirm what the user wants to do next.
            continueCheck();
            //Calls the pictureChange method to alter the image and proceed with the next event depending on the currentPositionCounter.
            pictureChange();
        }

        private void pctBoxDisplay_Click(object sender, EventArgs e)
        {
            //Changes the displayed image to a picture of Queen Elizabeth II at any time.
            pctBoxDisplay.Image = Properties.Resources.queenElizabeth;
        }
    }
}
