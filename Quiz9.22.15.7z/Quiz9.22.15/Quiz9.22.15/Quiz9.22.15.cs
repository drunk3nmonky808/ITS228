﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz9._22._15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonValidate_Click(object sender, EventArgs e)
        {
            ErrorClass errorClass = new ErrorClass();
            string stringReturn;
            //Validate name input
            stringReturn = errorClass.validateNameInput(textBoxNameInput.Text);
            if (stringReturn != "")
                MessageBox.Show(stringReturn,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            //Validate dateTime input
            stringReturn = errorClass.validateDateTimeInput(textBoxDateTimeInput.Text);
            if (stringReturn != "")
                MessageBox.Show(stringReturn, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            //Validate distance input
            stringReturn = errorClass.validateDistanceInput(textBoxDistanceInput.Text);
            if (stringReturn != "")
                MessageBox.Show(stringReturn, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            //if (stringReturn != "")
            //{
            //    MessageBox.Show(stringReturn, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //else
            //{
            //    MessageBox.Show("Your name is " + textBoxNameInput.Text, "First Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }
    }
}
