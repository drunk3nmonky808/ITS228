﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz9._22._15
{
    class ErrorClass
    {
        public string validateNameInput(string stringName)
        {
            string error = "";
            foreach (char ltr in stringName)
            {
                if (!Char.IsLetter(ltr))
                {

                    error = "Please enter only text";
                }
            }
            return error;
        }

        public string validateDateTimeInput(string stringDateTimeToday)
        {
            string error = "";
            DateTime tester;
            if (!DateTime.TryParse(stringDateTimeToday, out tester))
                error = "Please enter a correct date and time";
            return error;
        }

        public string validateDistanceInput(string stringDistance)
        {
            string error = "";
            decimal tester;
            if (!decimal.TryParse(stringDistance, out tester))
                error = "Please enter a distance";
            return error;
        }
    }
}
